const char* QN_intvec_rcsid = "$Header: /u/drspeech/repos/quicknet2/QN_intvec.cc,v 1.3 2004/04/01 23:04:22 davidj Exp $";

// Integer vector utility routines for QuickNet

#include "QN_intvec.h"

